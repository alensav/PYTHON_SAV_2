<?php
	//Webmoney Purse
	$wm_login = "";
	//Webmoney Password
	$wm_pass = "";
	//ROBOKASSA description
	$inv_desc = __("File for download");
?>
