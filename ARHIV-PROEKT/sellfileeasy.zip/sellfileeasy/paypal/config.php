<?php
	//Login
	$business = "vitalyreznik@gmail.com";
	//Currency
	$currency_code = "USD";
?>
