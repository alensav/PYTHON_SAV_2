<?php

$lang = array (

// RUB
'67654743cc32dfeebf2d2d154db69cd8' => 'Грн.',

// File for download
'f9965e933cc06e1aac09653b4ce318d7' => 'Файл для скачування',

// Error, download limit
'a038bad731a72952a8e10ce93b47b43d' => 'Помилка перевищений ліміт',

// Error, file name
'29a95460090577072674e73a3188f9dc' => 'Неправильне ім’я файлу',

// Error, time limit
'23894cf46cd91ee4cd9dced70d46c3d5' => 'Помилка перевищений ліміт часу',

// Error token
'21833c08ccdac6e0e2ab6e327e010f2f' => 'Помилковий хеш',

// SellFileEasy
'93f525bc62958c8673f9c81751eb3c96' => 'SellFileEasy',

// Statistics
'c33e404a441c6ba9648f88af3c68a1ca' => 'Статистика',

// File name is
'98d8127b69760b30dd51082e51382172' => 'Файл',

// Available time in minutes
'50c12800b90cb945965cecf6a08e1adb' => 'Доступність посилання у хвилинах',

// unlimited
'958f470d0b1c8fb2b9e62b48e8903299' => 'безлімітно',

// expired
'c4bfb2a0bab0e91bc7dcfbe3bbec246e' => 'прострочений',

// Available downloads
'd673a9be03d216ce9a2ef3939160f06c' => 'Залишилося завантажень',

// Order page
'0159108839abd78cbb894a4f19122660' => 'Сторінка замовлення',

// Wrong email, or email not match
'c7aedbf5af85aa8ec0572826bc064d10' => 'Помилковий email, або email-и не збігаються',

// File cost is
'56f1eeee05f255d40a8cd9f2f41dd533' => 'Вартість',

// Link will be available for
'a46f2db623819422227409976866f64b' => 'Посилання буде активне',

// minutes
'640fd0cc0ffa0316ae087652871f4486' => 'хвилин',

// unlimited time
'c46063e8e77e8bc2f7053f167875e695' => 'безлімітне час',

// and
'be5d5d37542d75f93a87094459f76678' => 'і',

// downloads
'd07d50a751bc6ddf12bf3af0efee9b45' => 'завантажень',

// Link for downloading will be sent to the e-mail after payment
'dd5e41717e229ec9ca1d10ab75ba342e' => 'Після оплати посилання для скачування буде вислана на цей e-mail',

// Email
'ce8ae9da5b7cd6c3df2929543a9af92d' => 'E-mail',

// Confirm
'70d9be9b139893aa6c69b5e77e614311' => 'Eщё раз',

// Submit
'a4d3b161ce1309df1c4e25df28694b7b' => 'Оформити замовлення',

// Choice payment gateway
'1f83da67ffead8a93bf126379e1fd8d9' => 'Виберіть спосіб оплати',

// Payment rejected!
'd00f9d5e77964e8bb901ae431b612486' => 'Платіж скасовано!',

// Link to download
'2749773be752c24b67a33b6b5059d355' => 'Посилання для скачування',

// Check link
'6ef7a5484bc62233c6bee80f378ffb21' => 'Посилання для перевірки',

// Login
'99dea78007133396a7b8ed70578ac6ae' => 'Логін',

// Password
'dc647eb65e6711e155375218212b3964' => 'Пароль',

// Enter
'f1851d5600eae616ee802a31ac74701b' => 'Вхід',

// Quit
'0d82790b0612935992bd564a17ce37d6' => 'Вийти',

// Download URL list
'f38e968714408174caf336df6ec2ec2b' => 'Завантажити список URL',

// Download CSV
'54df9536f2bc89e18bec27b0d34ab42e' => 'Завантажити замовлення в CSV',

// Are you sure?
'729a51874fe901b092899e9e8b31c97a' => 'Ви впевнені?',

// Clear ALL !!!
'a7466e5ac128a42efa3324bd04188651' => 'Очистити статистику',

// Begin time
'b1e28fbf2556170ef4b0211197124e84' => 'Початок звіту',

// Donload link
'cf0a796ea178035ff9008d86402adf5b' => 'Посилання для скачування',

// Downloads left
'deb5500af8cfca7a78a1de495b3f9bdc' => 'Залишилося завантажити',

// Cost
'20b4f77bd00b4f63a49ec8e08f3bf6a6' => 'Ціна',

// Reset / Delete
'a391e07e17597b3b54f84076053f0bee' => 'Активувати / Видалити',

// Download link
'10b599fca5f2bc272a0b5cbbac104b24' => 'Посилання для скачування',

// Powered by
'7a52e36bf4a1caa031c75a742fb9927a' => 'Powered by',

// Design by
'257074ebf9e756ac59cbd5a883080f21' => 'Design by',

// Payment successful!
'649b02d931f38c1cee39decce6c5e5d0' => 'Платіж прийнято!',

// Payment success! Check your Email.
'b226efd497e534385c53e64008e94873' => 'Платіж прийнято! Перевірте Ваш E-mail. ',

// minutes, and
'8a653eb8a924478d6b46c984e18e4934' => 'хвилин, і',

// times
'f2b798f672d4b42c0359ced11d4f10cd' => 'раз',

// Paid by
'48a2c9003c0889dcb8905bd0f51f65ab' => 'Оплата',

);

?>
