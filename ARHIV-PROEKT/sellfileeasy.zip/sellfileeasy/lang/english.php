<?php
	$lang = array(
	//RUB
	'67654743cc32dfeebf2d2d154db69cd8' => 'RUB',
	//File for download
	'f9965e933cc06e1aac09653b4ce318d7' => 'File for download',
	//Error, download limit
	'a038bad731a72952a8e10ce93b47b43d' => 'Error, download limit',
	//Error, file name
	'29a95460090577072674e73a3188f9dc' => 'Error, file name',
	//Error, time limit
	'23894cf46cd91ee4cd9dced70d46c3d5' => 'Error, time limit',
	//Error token
	'21833c08ccdac6e0e2ab6e327e010f2f' => 'Error token',
	//SellFileEasy
	'93f525bc62958c8673f9c81751eb3c96' => 'SellFileEasy',
	//Statistics
	'c33e404a441c6ba9648f88af3c68a1ca' => 'Statistics',
	//File name is
	'98d8127b69760b30dd51082e51382172' => 'File name is',
	//Available time in minutes
	'50c12800b90cb945965cecf6a08e1adb' => 'Available time in minutes',
	//unlimited
	'958f470d0b1c8fb2b9e62b48e8903299' => 'unlimited',
	//expired
	'c4bfb2a0bab0e91bc7dcfbe3bbec246e' => 'expired',
	//Available downloads
	'd673a9be03d216ce9a2ef3939160f06c' => 'Available downloads',
	//Order page
	'0159108839abd78cbb894a4f19122660' => 'Order page',
	//Wrong email, or email not match
	'c7aedbf5af85aa8ec0572826bc064d10' => 'Wrong email, or email not match',
	//File cost is
	'56f1eeee05f255d40a8cd9f2f41dd533' => 'File cost is',
	//Link will be available for
	'a46f2db623819422227409976866f64b' => 'Link will be available for',
	//minutes
	'640fd0cc0ffa0316ae087652871f4486' => 'minutes',
	//unlimited time
	'c46063e8e77e8bc2f7053f167875e695' => 'unlimited time',
	//and
	'be5d5d37542d75f93a87094459f76678' => 'and',
	//downloads
	'd07d50a751bc6ddf12bf3af0efee9b45' => 'downloads',
	//Link for downloading will be sent to the e-mail after payment
	'dd5e41717e229ec9ca1d10ab75ba342e' => 'Link for downloading will be sent to the e-mail after payment',
	//Email
	'ce8ae9da5b7cd6c3df2929543a9af92d' => 'Email',
	//Confirm
	'70d9be9b139893aa6c69b5e77e614311' => 'Confirm',
	//Submit
	'a4d3b161ce1309df1c4e25df28694b7b' => 'Submit',
	//Choice payment gateway
	'1f83da67ffead8a93bf126379e1fd8d9' => 'Choice payment gateway',
	//Payment rejected!
	'd00f9d5e77964e8bb901ae431b612486' => 'Payment rejected!',
	//Link to download
	'2749773be752c24b67a33b6b5059d355' => 'Link to download',
	//Check link
	'6ef7a5484bc62233c6bee80f378ffb21' => 'Check link',
	//Login
	'99dea78007133396a7b8ed70578ac6ae' => 'Login',
	//Password
	'dc647eb65e6711e155375218212b3964' => 'Password',
	//Enter
	'f1851d5600eae616ee802a31ac74701b' => 'Enter',
	//Quit
	'0d82790b0612935992bd564a17ce37d6' => 'Quit',
	//Download URL list
	'f38e968714408174caf336df6ec2ec2b' => 'Download URL list',
	//Download CSV
	'54df9536f2bc89e18bec27b0d34ab42e' => 'Download CSV',
	//Are you sure?
	'729a51874fe901b092899e9e8b31c97a' => 'Are you sure?',
	//Clear ALL!!!
	'a7466e5ac128a42efa3324bd04188651' => 'Clear ALL!!!',
	//Begin time
	'b1e28fbf2556170ef4b0211197124e84' => 'Begin time',
	//Donload link
	'cf0a796ea178035ff9008d86402adf5b' => 'Donload link',
	//Downloads left
	'deb5500af8cfca7a78a1de495b3f9bdc' => 'Downloads left',
	//Cost
	'20b4f77bd00b4f63a49ec8e08f3bf6a6' => 'Cost',
	//Reset / Delete
	'a391e07e17597b3b54f84076053f0bee' => 'Reset / Delete',
	//Download link
	'10b599fca5f2bc272a0b5cbbac104b24' => 'Download link',
	//Powered by
	'7a52e36bf4a1caa031c75a742fb9927a' => 'Powered by',
	//Design by
	'257074ebf9e756ac59cbd5a883080f21' => 'Design by',
	//Payment successful!
	'649b02d931f38c1cee39decce6c5e5d0' => 'Payment successful!',
	//Payment success! Check your Email.
	'b226efd497e534385c53e64008e94873' => 'Payment success! Check your Email.',
	//minutes, and
	'8a653eb8a924478d6b46c984e18e4934' => 'minutes, and',
	//times
	'f2b798f672d4b42c0359ced11d4f10cd' => 'times',

	//Paid by
	'48a2c9003c0889dcb8905bd0f51f65ab' => 'Paid by',
	);
?>
