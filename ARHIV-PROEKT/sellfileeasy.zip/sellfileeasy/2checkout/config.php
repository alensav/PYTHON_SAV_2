<?php
	//2checkout Login
	$sid = "";
	//2checkout Password
	$co_password = "";
	//2checkout exchange rate to 1$
	$co_exchange_rate = "55";
	//2checkout description
	$li_0_name = __("File for download");
?>
