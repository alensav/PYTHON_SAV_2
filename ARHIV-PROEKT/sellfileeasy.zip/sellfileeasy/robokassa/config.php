<?php
	//ROBOKASSA Login
	$mrh_login = "ARHIV-PROEKT";
	//ROBOKASSA Password 1
	$mrh_pass1 = "Ro485127_sav";
	//ROBOKASSA Password 2
	$mrh_pass2 = "2Ro485127_sav";
	//ROBOKASSA description
	$inv_desc = __("File for download");
	//ROBOKASSA currency
	$in_curr = "WMRM";
	//ROBOKASSA language, and script language
	$culture = "ru";
	//ROBOKASSA encoding
	$encoding = "UTF-8";
?>
