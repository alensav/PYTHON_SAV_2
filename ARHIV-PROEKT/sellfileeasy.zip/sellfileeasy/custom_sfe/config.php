<?php
	//Password few simbols for md5 hash
	$custom_sfe_pass = "";
?>
