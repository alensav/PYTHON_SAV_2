<?php
	//ID из вкладки "Данные магазина"
	//https://ishop.qiwi.com/options/http.action
	$qiwi_SHOP_ID = "";
	//API ID из вкладки "Данные магазина"
	// https://ishop.qiwi.com/options/rest.action
	$qiwi_REST_ID = "";
	$qiwi_REST_KEY = "";
	//API пароль из вкладки "Данные магазина"
	// https://ishop.qiwi.com/options/rest.action
	$qiwi_Pull_PWD = "";
	//Description
	$qiwi_desc = __("File for download");
	//Currency
	$qiwi_currency = 'RUB';
?>
