<?php
	//Shop ID
	$ya_receiver = '';
	//Sekret key
	$ya_secret_key = '';
	//Description
	$ya_desc = __("File for download");
?>
