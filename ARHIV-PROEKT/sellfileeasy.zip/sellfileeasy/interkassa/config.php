<?php
	//Shop ID
	$ik_shop_id = '';
	//Secret Key
	$ik_secret_key = '';
	//Initial Key(the same as ik_secret_key, or any key from interkassa Test field for test only)
	$ik_initial_key = '';
	//Description
	$ik_desc = __("File for download");
	//Currency
	$ik_currency = 'RUB';
	//Language
	$ik_locale = 'ru';
?>
